# Nexus Dashboard

React + CSS dashboard that polls the Nexus API server and shows the
`WorldModel` live: tasks, budget, risks, knowledge, and a scrolling ticker
of `EventBus` activity.

## Run

**1. Start the API server** (from the repo root):
```bash
pip install -r requirements.txt
cp .env.example .env   # fill in OPENAI_API_KEY / OPENAI_BASE_URL / OPENAI_MODEL
python -m server.app
```
This serves the API at `http://localhost:8000`.

**2. Start the dashboard** (from `web/`):
```bash
npm install
npm run dev
```
Opens at `http://localhost:5173`.

## Using it

- Type a goal in the top bar and hit **Run** — the Executive agent
  bootstraps tasks, a budget breakdown, and initial risks.
- Type a problem (e.g. "Our hardware supplier just failed") under
  **Inject a problem** and hit **Trigger** — watch Research/Planning/Risk
  agents adapt the plan, and the risk/task panels update within ~2.5s
  (the dashboard polls `/api/world`).
- The ticker at the bottom shows every event published on the `EventBus`
  as it happens — this is what makes the "cascading, connected system"
  idea visible instead of just described.
- **Reset project** clears state for a fresh demo run.

## Config

Point the dashboard at a different API host by setting `VITE_API_BASE`
in a `.env` file inside `web/`:
```
VITE_API_BASE=http://localhost:8000
```
