# Nexus — Execution Operating System

A pluggable multi-agent framework in Python (Executive, Planning, Research,
Finance, Risk agents) with a FastAPI backend and a React dashboard that
shows the shared project state live.

Agents share a `WorldModel` (tasks, budget, risks, knowledge) and talk
through an `EventBus`, so one agent's action can trigger another — e.g.
overspending publishes `budget.exceeded`, and the Risk agent automatically
logs a risk in response, without being explicitly asked.

## Layout

```
nexus/
├── nexus/                    # the agent framework
│   ├── core/
│   │   ├── world_model.py    # shared state: tasks, budget, risks, knowledge
│   │   ├── event_bus.py      # pub/sub for cascading agent reactions
│   │   ├── base_agent.py     # LLM + tool-use loop every agent inherits
│   │   └── registry.py       # @register_agent, discover agents by name
│   └── agents/
│       ├── executive_agent.py   # entry point: goal -> delegates to specialists
│       ├── planning_agent.py    # goal/change -> tasks
│       ├── research_agent.py    # findings -> knowledge base
│       ├── finance_agent.py     # budget lines, spend tracking
│       └── risk_agent.py        # risk logging, auto-reacts to events
│
├── server/
│   └── app.py                # FastAPI server exposing WorldModel as JSON
│
├── web/                       # React + CSS dashboard
│   ├── src/
│   │   ├── App.jsx           # polls the API, renders tasks/budget/risks/ticker
│   │   ├── tokens.css        # design tokens (color, type)
│   │   └── dashboard.css     # layout + components
│   └── ...
│
├── examples/run_demo.py       # CLI demo (no server/dashboard needed)
└── tests/                     # offline tests, no API key required
```

## Backend: OpenAI-compatible

Uses the OpenAI-compatible `chat.completions` API — works with real
OpenAI, [Featherless.ai](https://featherless.ai), or any compatible host.

```bash
pip install -r requirements.txt
cp .env.example .env   # fill in OPENAI_API_KEY / OPENAI_BASE_URL / OPENAI_MODEL
```

## Run the CLI demo (no dashboard)

```bash
python examples/run_demo.py
```

## Run the full dashboard

**1. Start the API server:**
```bash
python -m server.app
```
Serves at `http://localhost:8000`. Health check: `GET /api/health`.

**2. Start the dashboard** (separate terminal, from `web/`):
```bash
cd web
npm install
npm run dev
```
Opens at `http://localhost:5173`. Type a goal, hit **Run**, watch the
agents build a task plan + budget + risks live. Type a mid-project problem
under "Inject a problem" to see agents adapt the plan, with every
`EventBus` event scrolling in the ticker at the bottom.

## Run tests (no API key required)

```bash
pytest tests/
```

## Adding a new agent

```python
from nexus.core.base_agent import BaseAgent
from nexus.core.registry import register_agent

@register_agent
class TeamAgent(BaseAgent):
    name = "team_agent"
    description = "You coordinate people and responsibilities."

    def tools(self):
        return [{
            "name": "assign_person",
            "description": "Assign a person to a role/task.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "role": {"type": "string"},
                },
                "required": ["name", "role"],
            },
        }]

    def handle_tool_call(self, tool_name, tool_input):
        if tool_name == "assign_person":
            person = self.world.add_person(**tool_input)
            return {"person_id": person.id}
```

## Status

Working MVP: Executive, Planning, Research, Finance, Risk agents; a
FastAPI backend; a live React dashboard. Not yet implemented: Builder,
Analytics, Simulation agents, the visual Workflow Engine, and
multi-tenant/marketplace layers — natural next PRs on the same
`BaseAgent`/`WorldModel` pattern.
